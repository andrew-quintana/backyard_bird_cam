/**
 * API utilities for interacting with the Bird Detection Server API
 */

// Base URL for API requests (automatically detects if we're in development or production)
const BASE_URL = typeof window !== 'undefined' 
  ? window.location.pathname.startsWith('/v0') 
    ? '../api' // If running under /v0 path
    : '/api'   // If running as primary UI
  : '/api';    // Default for SSR

/**
 * Get recent bird detection results
 */
export async function getResults(options?: {
  limit?: number;
  offset?: number;
  birdOnly?: boolean;
  withSpecies?: boolean;
}) {
  const params = new URLSearchParams();
  
  if (options?.limit) params.append('limit', options.limit.toString());
  if (options?.offset) params.append('offset', options.offset.toString());
  if (options?.birdOnly) params.append('bird_only', 'true');
  if (options?.withSpecies) params.append('with_species', 'true');
  
  const response = await fetch(`${BASE_URL}/results?${params.toString()}`);
  
  if (!response.ok) {
    throw new Error(`Failed to fetch results: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Get a specific bird detection result by ID
 */
export async function getResult(id: number) {
  const response = await fetch(`${BASE_URL}/results/${id}`);
  
  if (!response.ok) {
    throw new Error(`Failed to fetch result ${id}: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Search for bird detection results
 */
export async function searchResults(options: {
  query?: string;
  startDate?: string;
  endDate?: string;
  minConfidence?: number;
  species?: string;
  limit?: number;
}) {
  const params = new URLSearchParams();
  
  if (options.query) params.append('q', options.query);
  if (options.startDate) params.append('start_date', options.startDate);
  if (options.endDate) params.append('end_date', options.endDate);
  if (options.minConfidence) params.append('min_confidence', options.minConfidence.toString());
  if (options.species) params.append('species', options.species);
  if (options.limit) params.append('limit', options.limit.toString());
  
  const response = await fetch(`${BASE_URL}/search?${params.toString()}`);
  
  if (!response.ok) {
    throw new Error(`Failed to search results: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Get bird detection statistics
 */
export async function getStats() {
  const response = await fetch(`${BASE_URL}/stats`);
  
  if (!response.ok) {
    throw new Error(`Failed to fetch stats: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Upload an image for bird detection
 */
export async function uploadImage(file: File) {
  const formData = new FormData();
  formData.append('file', file);
  
  const response = await fetch(`${BASE_URL}/upload`, {
    method: 'POST',
    body: formData,
  });
  
  if (!response.ok) {
    throw new Error(`Failed to upload image: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Resolve an image URL
 */
export function getImageUrl(path: string) {
  if (!path) return '';
  
  // If path already starts with 'http' or '/', use it as is
  if (path.startsWith('http') || path.startsWith('/')) {
    return path;
  }
  
  // Otherwise, prepend the base path
  return `/images/${path}`;
}

// Mock data for development without a server
export const mockData = {
  recentResults: [
    {
      id: 1,
      timestamp: '2025-05-01T08:30:00',
      bird_detected: true,
      bird_count: 1,
      species: 'Northern Cardinal',
      confidence: 0.92,
      image_path: '/placeholder.svg?height=400&width=600'
    },
    {
      id: 2,
      timestamp: '2025-05-01T09:15:00',
      bird_detected: true,
      bird_count: 2,
      species: 'Blue Jay',
      confidence: 0.88,
      image_path: '/placeholder.svg?height=400&width=600'
    },
    // Add more mock results as needed
  ],
  
  stats: {
    total_detections: 342,
    bird_detections: 296,
    species_identified: 23,
    average_confidence: 0.86,
    top_species: [
      { species: 'Northern Cardinal', count: 47 },
      { species: 'American Robin', count: 38 },
      { species: 'Blue Jay', count: 31 },
      { species: 'Chickadee', count: 28 },
      { species: 'Goldfinch', count: 22 }
    ],
    recent_counts: [
      { date: '2025-05-01', count: 12 },
      { date: '2025-04-30', count: 8 },
      { date: '2025-04-29', count: 15 },
      { date: '2025-04-28', count: 11 },
      { date: '2025-04-27', count: 9 },
      { date: '2025-04-26', count: 14 },
      { date: '2025-04-25', count: 10 }
    ]
  }
}; 