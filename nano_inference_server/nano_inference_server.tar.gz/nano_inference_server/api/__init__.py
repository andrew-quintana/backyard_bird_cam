"""
API module for serving bird detection results.

This module provides a REST API and web interface for bird detection results.
""" 