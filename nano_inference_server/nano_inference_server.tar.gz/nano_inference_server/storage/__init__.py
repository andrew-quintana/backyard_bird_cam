"""
Storage module for bird detection results.

This module handles storing, retrieving, and managing detection results.
""" 