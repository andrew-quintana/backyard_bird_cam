"""
Inference module for bird detection models.

This module handles loading and running inference on bird detection models.
""" 