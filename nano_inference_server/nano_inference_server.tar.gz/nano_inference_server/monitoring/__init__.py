"""
Monitoring module for detecting new images.

This module watches directories for new images and triggers processing.
""" 